package DAO;

import Beans.Company;

import java.util.ArrayList;

public interface CompaniesDAO {

    int isCompanyExists(String email, String password);
    boolean addCompany(Company company);
    boolean updateCompany(Company company);
    boolean deleteCompany(int companyID);
    Company getOneCompany(int companyID);
    ArrayList<Company> getAllCompanies();
}
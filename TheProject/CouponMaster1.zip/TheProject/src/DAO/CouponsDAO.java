package DAO;

import Beans.Coupon;

import java.util.ArrayList;

public interface CouponsDAO {

    boolean addCoupon(Coupon coupon);
    boolean updateCoupon(Coupon coupon);
    boolean deleteCoupon(int couponID);
    Coupon getOneCoupon(int couponID);
    ArrayList<Coupon> getAllCoupons();
    boolean addCouponPurchase(int customerID, int couponID);
    boolean deleteCouponPurchase(int customerID, int couponID);
}
package DAO;

import Beans.Customer;

import java.sql.SQLException;
import java.util.ArrayList;

public interface CustomersDAO {

    int isCustomerExists(String email, String password);
    boolean addCustomer(Customer customer);
    boolean updateCustomer(Customer customer);
    boolean deleteCustomer (int customerID);
    Customer getOneCustomer(int customerID);
    ArrayList<Customer> getAllCustomers();
}
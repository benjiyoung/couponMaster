package Login;

public enum ClientType {
    ADMINISTRATOR, COMPANY, CUSTOMER
}

package Login;

import Exceptions.CouponMasterException;
import Facades.AdminFacade;
import Facades.ClientFacade;
import Facades.CompanyFacade;
import Facades.CustomerFacade;

public class LoginManager {
    private static LoginManager instance = null;
    protected AdminFacade adminFacade = new AdminFacade();
    protected CompanyFacade companyFacade = new CompanyFacade();
    protected CustomerFacade customerFacade = new CustomerFacade();

    private LoginManager() {
    }

    public static LoginManager getInstance() {
        if (instance == null) {
            synchronized (LoginManager.class) {
                if (instance == null) {
                    instance = new LoginManager();
                }
            }
        }
        return instance;
    }

    public ClientFacade login(String email, String password, ClientType clientType) throws CouponMasterException {
        ClientFacade result = null;
        switch (clientType) {
            case ADMINISTRATOR -> result = (adminFacade.login(email, password)) ? adminFacade : null;
            case COMPANY -> result = (companyFacade.login(email, password)) ? companyFacade : null;
            case CUSTOMER -> result = (customerFacade.login(email, password)) ? customerFacade : null;
        }
        if (result == null)
            throw new CouponMasterException("Login failed! Please try again.");
        return result;
    }
}